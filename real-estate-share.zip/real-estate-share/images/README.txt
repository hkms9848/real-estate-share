매물 사진을 이 폴더에 넣으세요. 예: house-1.webp
index.html의 photos: ['images/house-1.webp'] 로 연결합니다.
사진은 직접 촬영했거나 공유 권한이 있는 파일만 사용하세요.
